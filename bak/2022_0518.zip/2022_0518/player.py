import pygame
import sys
import time
import place

diceDegree = (0, 0, 120, 240)


class Player:
    def __init__(self, index):
        self.index = index
        self.money = 325
        self.location = 0
        self.building = []
        self.penalty = 0

    # 주사위 던지는 함수
    def throwDice(self, game, display, playerInfo):
        # 인경호에 빠졌으면 안내 문구 출력
        if self.penalty > 0:
            print("당신은 인경호에 빠져 있습니다. 더블이 나오면 탈출합니다!")
            time.sleep(0.5)

        done = False
        double = False

        while not done:
            for event in pygame.event.get():
                # 엔터 키 감지 시
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    dice1, dice2 = display.diceRotate()
                    # 더블일 경우
                    if dice1 == dice2:
                        # 인경호에 빠져있는 경우
                        if self.penalty > 0:
                            print("\n축하합니다! 인경호를 탈출합니다.")
                            self.penalty = 0
                            done = True
                        # 더블이 처음인 경우
                        elif not double:
                            print("\n더블입니다! 주사위를 한번 더 던집니다.")
                            double = True
                        # 더블이 연속 2번인 경우
                        else:
                            done = True
                    # 더블이 아닌 경우
                    else:
                        done = True
                        # 인경호에 빠져있었으면 탈출 실패 문구 출력
                        if self.penalty > 0:
                            print("탈출에 실패했습니다..")

                    if self.penalty <= 0:
                        self.move(game, display, playerInfo, dice1, dice2)

                # 게임 창 닫기 버튼을 눌렀을 경우
                elif event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

    def move(self, game, display, playerInfo, dice1, dice2):
        move = dice1 + dice2

        diceImage1 = pygame.transform.rotate(display.diceImage, diceDegree[dice1])
        diceImage2 = pygame.transform.rotate(display.diceImage, diceDegree[dice2])

        myString = str(move) + "칸을 이동합니다."
        display.text(myString, display.textLocation)
        display.update()

        time.sleep(0.5)

        # 이동할 칸 수만큼 반복하여 game.moveDisplay 함수 호출
        for i in range(move):
            # 1칸씩 이동
            self.location += 1
            # 출발점을 지나면 위치 index 클리어
            if self.location >= len(place.placeList):
                self.getMoney(20)
                self.location = 0
            # 보드, 플레이어 아이콘 표시
            display.board()
            display.building(game, playerInfo)
            display.player(game, playerInfo)
            display.playerInfo(game, playerInfo)
            display.dice(diceImage1, diceImage2)
            display.text(myString, display.textLocation)
            display.update()

            time.sleep(0.5)

    def getMoney(self, money):
        self.money += money

    def payMoney(self, display, money):
        self.money -= money
        display.text("요금 %d만원을 지불하였습니다." % money, (230, 600))

    def buyBuilding(self, display, building):
        self.payMoney(display, building.fee)
        self.building.append(building.name)
        building.owner = self.index

    def sellBuilding(self, building):
        self.building.remove(building)


def initPlayer(num):
    # player 객체 배열 초기화
    player = []
    # 플레이어 수만큼 객체 배열 생성
    for i in range(num):
        player.append(Player(i))

    return player
