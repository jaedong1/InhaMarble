# 장소(칸) index 리스트
placeList = range(28)
# 장소 이름
placeName = ("출발점", "미래융합대학", "9호관", "체육관", "김현태 인하드림센터", "비룡탑", "학생회관", "하나은행", "6호관", "C호관",
             "인하드림센터 2~3호관", "하이테크센터", "1호관", "4호관", "우남호", "2호관", "60주년 기념관", "농구장", "5호관",
             "서호관", "나빌레관", "인경호", "비룡주차장", "대운동장", "정석학술정보관", "학군단", "테니스장", "로스쿨관")
# 장소 좌표
placeLocation = ((320, 440), (364, 404), (406, 379), (447, 353), (490, 327), (530, 301), (570, 276), (615, 250),
                 (565, 221), (525, 193), (485, 164), (442, 136), (401, 107), (359, 79), (320, 50),
                 (275, 75), (235, 100), (200, 130), (160, 160), (120, 185), (70, 220), (20, 240),
                 (65, 275), (120, 305), (160, 340), (200, 365), (235, 390), (275, 420))


class Place:
    def __init__(self, name, fee):
        self.name = name
        self.fee = fee
        self.owner = None

    def checkEvent(self, game, display, playerInfo, index):
        if self.name == "하나은행":
            self.goldenKey()
        elif self.name == "우남호":
            self.airplane()
        elif self.name == "인경호":
            self.inhaLake()
        elif self.name == "미래융합대학" or self.name == "6호관" or self.name == "5호관" or self.name == "정석학술정보관":
            self.miniGame()
        else:
            self.normalPlace(game, display, playerInfo, index)

    def goldenKey(self):
        pass

    def airplane(self):
        pass

    def inhaLake(self):
        pass

    def miniGame(self):
        pass

    def normalPlace(self, game, display, playerInfo, index):
        if playerInfo[index].money >= self.fee:
            if not self.owner:
                done = False
                while not done:
                    myString = self.name + "을(를) 구매할 수 있습니다. 구매하시겠습니까?"
                    display.text(myString, display.textLocation)
                    display.update()

                    answer = input()
                    if answer == 'y':
                        print("%s을(를) 구매하였습니다." % self.name)
                        playerInfo[index].buyBuilding(game, playerInfo, display, self.name, self.fee)
                        self.owner = playerInfo[index].index

                        done = True

                    elif answer == 'n':
                        playerInfo[index].payMoney(game, playerInfo, display, self.fee)

                        done = True

                    else:
                        print("잘못 입력하셨습니다. 다시 입력하세요.")

            else:
                playerInfo[index].payMoney(game, playerInfo, display, self.fee)

        else:
            if not playerInfo[index].building:
                print("지불할 돈이 없어서 파산하였습니다..")
                playerInfo[index].penalty = -1

            else:
                print("매각할 건물을 선택하세요.")

    @staticmethod
    def initPlace():
        place = []
        for i in placeList:
            place.append(Place(placeName[i], 10))

        return place
